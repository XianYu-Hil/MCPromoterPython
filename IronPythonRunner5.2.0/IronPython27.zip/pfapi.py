#! /usr/bin/env python
# -*- coding:utf-8 -*-
def AddMoney(playername,value):
	'''增加玩家计分板金钱'''
	pass
def RemoveMoney(playername,value):
	'''扣除玩家计分板金钱'''
	pass
def GetMoney(playername):
	'''获取玩家计分板金钱'''
	pass
def GetUUID(playername):
	'''获取玩家uuid'''
	pass
def HasOpPermission(playername):
	'''返回一个bool值判断玩家是否有op权限'''
	pass
def FeedbackTellraw(playername,msg):
	'''返回tellraw消息'''
	pass
def SendActionbar(playername,msg):
	'''发送玩家Actionbar信息'''
	pass
def AddCommandDescribe(key,describe):
	'''添加指令描述'''
	pass
def DelCommandDescribe(key):
	'''删除指令描述'''
	pass
def ExecuteCmd(cmd):
	'''运行服务器命令(自动拦截刷屏)'''
	pass
def ExecuteCmdAs(playername,cmd):
	'''以玩家身份运行服务器命令(自动拦截刷屏)'''
	pass
